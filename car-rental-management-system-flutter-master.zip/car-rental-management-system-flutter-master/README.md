Car Rental management system App UI Flutter | Velocity X |Backend Firebase
Flutter based Car Rental management system App | Flutter | Velocity X | Backend Firebase

Custom Splash Screen with flare animation

Google login

Texts are animated with Shimmer

Animated Bottom Navigation Bar

Custom Animations

Custom Grid View

Dark Theme mode

Save The Application state (If you close the application it save the application state For Example dark theme enable or not and User login or not)

## Demo
Demo available on YouTube.

Link: 
https://youtu.be/mWFOnzAi4-w

## Screenshot


![Screenshot_20210114_191353](https://user-images.githubusercontent.com/54774962/104599082-5e7c7100-569d-11eb-9993-dfd868b14b1f.png)


![Screenshot_20210114_191401](https://user-images.githubusercontent.com/54774962/104599087-5f150780-569d-11eb-8250-bd53bfaf5a2d.png)


![Screenshot_20210114_191430](https://user-images.githubusercontent.com/54774962/104599091-60463480-569d-11eb-839c-dfe15dea7145.png)


![Screenshot_20210114_191446](https://user-images.githubusercontent.com/54774962/104599104-620ff800-569d-11eb-95a6-bc79be6a9f79.png)


![Screenshot_20210114_191455](https://user-images.githubusercontent.com/54774962/104599111-64725200-569d-11eb-8caf-86c6d12b10ba.png)


![Screenshot_20210114_191502](https://user-images.githubusercontent.com/54774962/104599113-650ae880-569d-11eb-96c7-96f8313e71d4.png)


## dark Mode


![Screenshot_20210114_191514](https://user-images.githubusercontent.com/54774962/104599121-65a37f00-569d-11eb-8643-1a041a8b9c3d.png)


![Screenshot_20210114_191530](https://user-images.githubusercontent.com/54774962/104599069-5ae8ea00-569d-11eb-8773-112a0d9da7e1.png)



## Inspiration

![car rendal app ui](https://user-images.githubusercontent.com/54774962/104598170-43f5c800-569c-11eb-9322-b1e0bbd9aa47.jpg)


